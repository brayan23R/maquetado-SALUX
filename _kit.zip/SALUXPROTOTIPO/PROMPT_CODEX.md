# Cómo pedírselo a Codex

## Antes de empezar
1. La carpeta del proyecto es `C:\ProyectosDev\SALUXPROTOTIPO` (aquí debe estar todo este kit).
2. Abre la app de escritorio de Codex y **abre esa carpeta como proyecto** (la raíz, no una subcarpeta).
3. Elige el modo de permisos que le deje **ejecutar comandos dentro de la carpeta** sin pedir confirmación en cada paso (necesita correr `flutter`, `docker`, `npm`, `adb`, etc.).
4. Abre antes **Docker Desktop** y espera a que diga "Running". El emulador lo crea el propio script.

## Prompt 1 (pégalo tal cual, es el principal)

```
Lee AGENTS.md y toda la carpeta docs\ (SPEC.md, SCREENS.md, DESIGN_TOKENS.json), revisa prototype\Main.dc.html, assets\, seed\ y supabase\migrations\0001_init.sql.

Tu misión: construir SALUX completo en C:\ProyectosDev\SALUXPROTOTIPO, como un ingeniero senior de software móvil, backend e infraestructura, siguiendo exactamente esa documentación. Estructura del repo, nombres de rutas y ubicación de assets según docs\SPEC.md §4.

Ejecuta las fases 0 a 6 de AGENTS.md en orden, sin detenerte ni pedir confirmación para tareas de rutina. Tú mismo ejecuta los comandos: instala dependencias, genera código, crea el emulador con .\scripts\02_create_emulator.ps1, levanta el backend con .\scripts\03_start_backend.ps1, compila e instala la app en el emulador con .\scripts\04_run_app.ps1 y verifica que cada pantalla abre y responde. Si un comando o script falla, diagnostica, corrige y repite hasta que funcione.

Reglas clave: las 57 pantallas deben verse y comportarse como el prototipo (claro y oscuro); usa los assets de assets\ sin redibujarlos (la mascota PNG en splash, bienvenida e inicio de sesión); modo mock completo sin internet y modo supabase contra el backend local; prueba gratis de 3 días decidida por el servidor; pagos con pasarela simulada que desbloquea Premium automáticamente; panel admin en apps\admin con MFA y métricas reales.

Al terminar cada fase: flutter analyze sin errores, pruebas en verde, commit y actualización de docs\PROGRESS.md. No pares hasta cumplir todo el "Definition of Done" de AGENTS.md §8. Solo pregúntame si falta una credencial que solo yo pueda dar (Google/Apple OAuth, pasarela de pago). Al final dime en pocas líneas cómo probar la app y dónde quedó el APK.
```

## Prompt 2 (si se detiene antes de terminar)
```
Continúa donde te quedaste. Lee docs\PROGRESS.md y la lista "Definition of Done" de AGENTS.md §8, revisa qué falta y sigue sin parar hasta completarla. Ejecuta y verifica en el emulador cada cosa que termines.
```

## Prompt 3 (verificación final)
```
Haz una auditoría completa contra docs\SCREENS.md: recorre las 57 pantallas en el emulador (claro y oscuro), confirma que cada botón navega a donde indica el catálogo, corrige las diferencias con prototype\Main.dc.html, ejecuta flutter analyze y todas las pruebas, y genera el APK con .\scripts\05_build_apk.ps1. Entrega una lista corta de lo corregido y lo pendiente.
```

## Prompt 4 (cambios puntuales, para cuando pruebes)
```
En la pantalla [nombre/ruta] cambia [lo que quieres]. Mantén el sistema de diseño de docs\DESIGN_TOKENS.json, actualiza las pruebas afectadas y verifica en el emulador.
```

## Atajo sin Codex (solo para probar el entorno)
Desde PowerShell, en la raíz del proyecto:
```
.\scripts\00_bootstrap.ps1                 # verifica todo, crea el emulador, instala y abre la app (modo mock)
.\scripts\00_bootstrap.ps1 -Mode supabase -WithAdmin   # con backend local y panel admin
```
(Solo funcionará cuando exista `apps\mobile`, que crea Codex en la Fase 0.)

## Qué pedirte a ti mismo en el camino
- Claves de Google y Apple (cuando quieras login real) y de la pasarela de pago (cuando contrates una): van en `.env`, nunca en Git.
- Revisar con un profesional el contenido de las preguntas y con un asesor legal los textos de términos y privacidad.
- Decidir cómo cobrar en tiendas (dentro de la app o web de checkout); Apple y Google suelen exigir sus propias compras para suscripciones digitales.
