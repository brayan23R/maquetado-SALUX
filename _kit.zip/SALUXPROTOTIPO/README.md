# SALUX · Kit de arranque

Esta carpeta contiene todo lo necesario para que Codex construya SALUX de principio a fin.

```
SALUXPROTOTIPO\
├─ AGENTS.md              Instrucciones permanentes (Codex las lee solo)
├─ PROMPT_CODEX.md        Los prompts exactos para pedírselo
├─ docs\                  SPEC (arquitectura), SCREENS (57 pantallas), DESIGN_TOKENS
├─ prototype\             Prototipo aprobado (referencia visual y de comportamiento)
├─ assets\                images\ (PNG de tu mascota), mascot\ (6 SVG), icons\ (69 SVG)
├─ seed\                  40 preguntas de ejemplo (JSON)
├─ supabase\migrations\   Esquema, seguridad (RLS) y funciones del servidor
├─ scripts\               Verificar entorno, emulador, backend, ejecutar, APK, admin
└─ .github\workflows\     CI (analizar, probar, generar APK)
```

Cómo empezar: abre esta carpeta en Codex y sigue `PROMPT_CODEX.md` (Prompt 1).

Cuando Codex termine, este archivo se reemplaza por el README final con instrucciones de uso.
